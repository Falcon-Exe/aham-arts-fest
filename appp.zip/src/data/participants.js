const participants = [
  { name: "Alice", event: "Group Dance", team: "Team A" },
  { name: "Bob", event: "Solo Singing", team: "Team B" },
];

export default participants;
