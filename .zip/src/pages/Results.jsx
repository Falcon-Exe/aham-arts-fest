function Results() {
  return <h2 style={{ textAlign: "center", padding: "50px" }}>Results Page Coming Soon 🏆</h2>;
}

export default Results;
