const results = [
  { event: "Group Dance", winner: "Team A", runnerUp: "Team C" },
  { event: "Solo Singing", winner: "Bob", runnerUp: "Charlie" },
];

export default results;
