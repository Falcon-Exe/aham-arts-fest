const schedule = [
  { time: "10:00 AM", event: "Group Dance", venue: "Main Stage" },
  { time: "11:30 AM", event: "Solo Singing", venue: "Auditorium" },
  { time: "1:00 PM", event: "Lunch Break", venue: "-" },
  { time: "2:00 PM", event: "Drama", venue: "Main Stage" },
  { time: "3:30 PM", event: "Art Exhibition", venue: "Gallery Hall" },
];

export default schedule;
